# Introduction

This is a description file for `CountryFilterBar`, written with Markdown.

# Description

It's a _nice_ component!
