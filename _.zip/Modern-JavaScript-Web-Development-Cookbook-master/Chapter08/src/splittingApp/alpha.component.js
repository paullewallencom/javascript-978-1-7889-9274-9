/* @flow */

import React from "react";

const Alpha = () => <h1>Alpha</h1>;

export default Alpha;
