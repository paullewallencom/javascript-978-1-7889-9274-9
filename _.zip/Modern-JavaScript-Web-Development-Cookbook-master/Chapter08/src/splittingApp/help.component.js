/* @flow */

import React from "react";

const Help = () => <h1>Help! SOS!</h1>;

export default Help;
