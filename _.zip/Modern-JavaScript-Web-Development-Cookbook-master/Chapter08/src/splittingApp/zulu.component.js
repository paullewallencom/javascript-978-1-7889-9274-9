/* @flow */

import React from "react";

const Zulu = () => <h1>Zulu</h1>;

export default Zulu;
