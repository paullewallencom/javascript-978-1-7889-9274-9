/* @flow */

import { StyledButton } from "./styledButton.a11y";
export { StyledButton };
