
// Auto-generated file created by react-native-storybook-loader
// Do not edit.
//
// https://github.com/elderfo/react-native-storybook-loader.git

function loadStories() {
  require('../src/regionsStyledApp/countrySelect.story');
  require('../src/regionsStyledApp/regionsTable.story');
  
}

const stories = [
  '../src/regionsStyledApp/countrySelect.story',
  '../src/regionsStyledApp/regionsTable.story',
  
];

module.exports = {
  loadStories,
  stories,
};
